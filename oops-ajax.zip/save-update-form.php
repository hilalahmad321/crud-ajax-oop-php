<?php

include "Database.php";
$obj=new Database();

$sid=$_POST["id"];
$fname=$_POST["fname"];
$lname=$_POST["lname"];

if($obj->update("student",["fname"=>$fname,"lname"=>$lname],"id={$sid}")){
    echo 1;
}else{
    echo 0;
}

?>