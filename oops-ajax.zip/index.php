<?php
include "Database.php";
$obj = new Database();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="w3.css">
    <title>OOP-AJAX</title>
</head>
<style>
    .box1 {
        display: none;
        background-color: #3948;
    }
</style>

<body>
    <div class="w3-container">
        <input type="text" name="search" id="search" class="w3-input w3-border">
    </div>
    <div class="box1">
        <h3>Data insert successfully</h3>
    </div>
    <button onclick='document.getElementById("id01").style.display="block"' class="w3-btn w3-blue w3-margin-top">Add Data</button>
    <div id="id01" class="w3-modal">
        <div class="w3-modal-content w3-animate-top">
            <div class="w3-container">
                <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-margin-top w3-display-bottomright w3-red w3-hover-red">Close</span>
                <form action="" method="post">
                    <label for="">Enter your first name</label>
                    <input type="text" name="fname" id="fname" class="w3-input w3-border">
                    <label for="">Enter your last name</label>
                    <input type="text" name="lname" id="lname" class="w3-input w3-border">
                    <button onclick="document.getElementById('id01').style.display='none'" type="submit" name="submit" id="submit" class="w3-button w3-green w3-hover-green">ADD</button>
                </form>
            </div>
        </div>
    </div>
    <form action="" method="post">
    </form>
    <table class='w3-table-all table-content'>
    </table>
    <script src="jquery.js"></script>
    <script>
        $(document).ready(function() {
            // Select data
            function loaddata() {
                $.ajax({
                    url: "select-data.php",
                    type: "POST",
                    success: function(data) {
                        $(".table-content").html(data);
                    }
                })
            }
            loaddata();
            // Insert data
            $("#submit").on("click", function(e) {
                e.preventDefault();
                var f_name = $("#fname").val();
                var l_name = $("#lname").val();
                $("form").trigger("reset");
                $.ajax({
                    url: "insert-data.php",
                    type: "POST",
                    data: {
                        fname: f_name,
                        lname: l_name
                    },
                    success: function(data) {
                        loaddata();
                        alert('data insert successfully');
                    }
                });
            });
            // update data
            $(document).on("click", "#edit", function() {
                var studen_id = $(this).data("eid");
                $.ajax({
                    url: "load-update-data.php",
                    type: "POST",
                    data: {
                        id: studen_id
                    },
                    success: function(data) {
                        $("form").html(data)
                    }
                });
            });
            $(document).on("click", "#edit-from", function() {
                var stid = $("#id").val();
                var f_name = $("#fname-edit").val();
                var l_name = $("#lname-edit").val();

                $.ajax({
                    url: "save-update-form.php",
                    type: "POST",
                    data: {
                        id: stid,
                        fname: f_name,
                        lname: l_name
                    },
                    success: function(data) {
                        if (data == 1) {
                            alert('data update successfully');
                            loaddata();
                        }
                    }
                });
            });
            $("#search").on("keyup", function() {
                var search = $(this).val();

                $.ajax({
                    url: "live-search.php",
                    type: "POST",
                    data: {
                        search_term: search
                    },
                    success: function(data) {
                        $(".table-content").html(data);
                    }
                });
            });
            // Delete record

            $(document).on("click", "#delete", function() {
                if(confirm("Are you sure you want to delete data")){
                    var deleteid = $(this).data("id");
                var element=this;
                $.ajax({
                    url: "delete-data.php",
                    type: "POST",
                    data: {
                        id: deleteid
                    },
                    success: function(data) {
                        if(data==1){
                            $(element).closest("tr").fadeOut();
                        }
                        
                    }
                });
                }
                
            });
        });
    </script>
</body>

</html>