<?php
include "Database.php";
$obj=new Database();

$fname=$_POST["fname"];
$lname=$_POST["lname"];
$obj->insert("student",["fname"=>$fname,"lname"=>$lname]);
if($obj){
    echo 1;
}else{
    echo 0;
}
?>