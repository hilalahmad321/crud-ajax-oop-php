<?php
include "Database.php";
$obj = new Database();
$search =$_POST["search_term"];
$row = $obj->select("student", "*", null, "fname LIKE '%{$search}%' OR lname LIKE '%{$search}%'", null, null);
$output = "";
$output = "<table class='w3-table-all table-content'
<tr>
<th>Id</th>
<th>Name</th>
<th>Edit</th>
<th>Delete</th>
</tr>
";
foreach ($row as $array) {
    $output.="<tr>
    <td>{$array["id"]}</td>
    <td>{$array["fname"]}  {$array["lname"]}</td>
    <td><button id='edit' data-eid={$array["id"]} class='w3-btn w3-green'>Edit</button></td>
    <td><button class='w3-btn w3-red'>Delete</button></td>
</tr>";
}
$output .= " </table>";
echo $output;
?>