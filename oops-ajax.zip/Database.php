<?php
class Database
{
    private $db_local = "localhost";
    private $db_name = "root";
    private $db_password = "";
    private $db_database = "oop";
    private $mysqli = "";

    public function __construct()
    {
        if (!$this->mysqli) {
            $this->mysqli = new mysqli($this->db_local, $this->db_name, $this->db_password, $this->db_database);
            if (!$this->mysqli) {
                echo "not connected to data base";
            }
        }
    }

    public function insert($table, $value)
    {
        $total_column = implode(",", array_keys($value));
        $total_value = implode("','", array_values($value));

        $sql = "INSERT INTO $table ($total_column) VALUES('$total_value')";
        $result = $this->mysqli->query($sql);
    }

    public function select($table, $row = "*", $join = null, $where = null, $order = null, $limit = null)
    {
        $sql = "SELECT $row FROM $table";
        if ($join != null) {
            $sql .= "JOIN $join";
        }
        if ($where != null) {
            $sql .= " WHERE $where";
        }
        if ($limit != null) {
            $sql = "LIMIT $limit";
        }
        $result = $this->mysqli->query($sql);
        while ($row = $result->fetch_assoc()) {
            $array[] = $row;
        }
        return $array;
    }
    public function update($table, $peram = array(), $where = null)
    {
        // $arg = array();
        // foreach ($peram as $key => $value) {
        //     $arg[] = "$key = '$value'";
        // }
        // $sql = " UPDATE $table SET " . implode(',', $arg);
        // var_dump($sql);
        // if ($where != null) {
        //     $sql .= "WHERE $where";
        // }
        // $result = $this->mysqli->query($sql);
        $arg=array();
        foreach ($peram as $key => $value){
            $arg[]="$key ='$value'";
        }
       $sql=" UPDATE $table SET ". implode(',',$arg);
        if($where != null){
            $sql.=" WHERE $where";
        }
        var_dump($sql);
        $result=$this->mysqli->query($sql);
    }
    // Delete data

    public function delete($table,$where=null){
        $sql="DELETE FROM $table";
        if($where != null){
            $sql.=" WHERE $where";
        }

        $result=$this->mysqli->query($sql);
    }
}
