<?php
include "Database.php";
$obj=new Database();

$student_id=$_POST["id"];

$row=$obj->select("student","*",null,"id='{$student_id}'",null,null);
$output="";
foreach($row as $array){
    $output.=" <label for=''>Enter your first name</label>
    <input type='text' hidden name='id' value='{$array["id"]}' id='id' class='w3-input w3-border'>
    <input type='text' name='fname' value='{$array["fname"]}' id='fname-edit' class='w3-input w3-border'>
    <label for=''>Enter your last name</label>
    <input type='text' name='lname' id='lname-edit' value='{$array["lname"]}' class='w3-input w3-border'>
    <button onclick=document.getElementById('id01').style.display='none' type='submit' name='submit' id='edit-from' class='w3-button w3-green w3-hover-green'>ADD</button>";
}
echo $output;

?>
                   