<?php
include "Database.php";

$obj=new Database();
$id=$_POST["id"];

$obj->delete("student","id='{$id}'");

if($obj){
    echo 1;
}else{
    echo 0;
}




?>